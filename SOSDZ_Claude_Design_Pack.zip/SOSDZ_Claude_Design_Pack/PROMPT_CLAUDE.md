# SOSDZ — PROMPT POUR CLAUDE

Tu es un designer UI/UX senior. Modernise SOSDZ en gardant la structure et les contenus existants.

IMPORTANT :
- Ne rien inventer.
- Ne modifier que ce que je demande.
- Conserver le header : logo SOSDZ + sélecteur de langue + menu hamburger.
- Conserver la navigation mobile basse.
- Donner une priorité visuelle très claire à « Lancer un SOS ».
- Espacer suffisamment les sections et boutons pour éviter les mauvais clics.
- Pas de bordures noires épaisses.
- Titres modernes, lisibles, pas excessivement gras.
- Fond principalement blanc.
- Rouge uniquement pour SOS/urgence/alerte.
- Utiliser les icônes SVG fournies dans /icons.
- Réutiliser les touches vert light, bleu light et orange light dans tout le site pour créer un langage visuel cohérent.
- Ne pas transformer toutes les sections en blocs fortement colorés.

PALETTE :
Vert #087A4B
Vert light #E8F7EF
Bleu #1976D2
Bleu light #EAF3FF
Orange #E68A00
Orange light #FFF4DF
Rouge SOS #E53935
Rouge soft #FFF0F0
Bleu nuit #102A43
Blanc #FFFFFF

ACCUEIL MOBILE :
1. Header
2. Message d’introduction
3. Grande carte « Lancer un SOS »
4. « Points de collecte en Algérie »
5. « Points de collecte à l’étranger »
6. « Créer un point de collecte »
7. Navigation basse

CARTES :
- radius 18–22 px
- ombre très légère
- padding 18–22 px
- espace entre cartes 18–24 px
- zone tactile minimum 48 px
- une carte = une action principale

HEADER :
Logo SOSDZ à gauche, sélecteur de langue, menu hamburger à droite. Rester léger et blanc. Ne rien ajouter au header sans demande.

NAVIGATION :
Accueil | SOS | Collecte Algérie | Collecte Internationale | Bénévoles

COULEURS LIGHT :
Vert light = collecte/aide/action positive.
Bleu light = international/information.
Orange light = création/ajout.
Rouge soft = urgence/SOS.

Ces touches doivent être reprises avec modération dans les pages internes, badges, filtres et cartes afin de conserver un rappel visuel cohérent.

Pour toute modification ultérieure : « Ne touche à rien d’autre. »
