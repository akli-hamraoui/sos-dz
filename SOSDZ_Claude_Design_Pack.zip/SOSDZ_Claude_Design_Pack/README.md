# SOSDZ — Pack design pour Claude

Contient le prompt, le design system, la palette et les icônes SVG.

Utilisation :
1. Ajouter ce dossier au contexte du projet Claude.
2. Fournir la capture mobile SOSDZ comme référence.
3. Commencer par PROMPT_CLAUDE.md.
4. Demander à Claude de conserver les éléments existants et de ne modifier que ce qui est demandé.
