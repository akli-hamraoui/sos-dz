# SOSDZ — Couleurs

| Usage | Couleur |
|---|---|
| Vert marque | #087A4B |
| Vert light | #E8F7EF |
| Bleu | #1976D2 |
| Bleu light | #EAF3FF |
| Orange | #E68A00 |
| Orange light | #FFF4DF |
| Rouge SOS | #E53935 |
| Rouge soft | #FFF0F0 |
| Texte bleu nuit | #102A43 |
| Fond | #FFFFFF |

Les couleurs light sont des accents récurrents. Le blanc reste la base. Le rouge ne doit pas être utilisé pour du texte informatif normal.
