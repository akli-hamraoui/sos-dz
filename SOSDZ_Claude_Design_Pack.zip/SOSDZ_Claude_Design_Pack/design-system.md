# SOSDZ — Design System

- Style : moderne, propre, humain, rassurant.
- Mobile first.
- Beaucoup d’espace entre les actions.
- Cartes arrondies 18–22 px.
- Ombres discrètes.
- Pas de cadres noirs épais.
- Typographie sans-serif, titres 600–700 maximum.
- Texte courant 400–500.
- Zones tactiles ≥ 48 px.
- Une action principale par carte.
- Icônes simples, linéaires et cohérentes.
- SOS en rouge.
- Collecte Algérie en vert.
- International en bleu.
- Création en orange.
- Navigation active en vert.
